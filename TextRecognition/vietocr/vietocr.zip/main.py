import matplotlib.pyplot as plt
from PIL import Image

from vietocr.tool.predictor import Predictor
from vietocr.tool.config import Cfg
from vietocr.model.trainer import Trainer

config = Cfg.load_config_from_name('vgg_transformer')



config['vocab'] = 'aAàÀảẢãÃáÁạẠăĂằẰẳẲẵẴắẮặẶâÂầẦẩẨẫẪấẤậẬbBcCdDđĐeEèÈẻẺẽẼéÉẹẸêÊềỀểỂễỄếẾệỆfFgGhHiIìÌỉỈĩĨíÍịỊjJkKlLmMnNoOòÒỏỎõÕóÓọỌôÔồỒổỔỗỖốỐộỘơƠờỜởỞỡỠớỚợỢpPqQrRsStTuUùÙủỦũŨúÚụỤưƯừỪửỬữỮứỨựỰvVwWxXyYỳỲỷỶỹỸýÝỵỴzZ0123456789!"#$%&\'()*+,-./:;<=>?[\\]^_`{|}~°‰µΔ '

dataset_params = {
    'name':'real_test_400',
    'data_root':'./Sorted/',
    'train_annotation':'annotation_full_656.txt',
    'valid_annotation':'annotation_full_test_376.txt'
}

predictor_params = {
    'beamsearch': True
}
params = {
         'print_every':200,
         'valid_every':400,
          'iters':800,
          'checkpoint':'./vietocr_triet/checkpoint/transformerocr_checkpoint.pth',    
          'export':'./vietocr_triet/weights/transformerocr_real_test_with_cal.pth',
          'metrics': 300
         }

config['trainer'].update(params)
config['dataset'].update(dataset_params)
config['predictor'].update(predictor_params)
config['device'] = 'cuda:0'
config['weights'] = './vietocr_triet/transformerocr.pth'

trainer = Trainer(config, pretrained=False)

trainer.train()